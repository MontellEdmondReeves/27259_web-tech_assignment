package com.auca.university.model;

import java.util.*;
import jakarta.persistence.*;


@Entity
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    private String title;
 
    private int credits;
 
    @ManyToOne
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;
 
    /** Many-to-Many inverse side: the join table is defined in Lecturer. */
    @ManyToMany(mappedBy = "courses")
    private List<Lecturer> lecturers = new ArrayList<>();
 
    /** One course has many registrations (join entity). */
    @OneToMany(mappedBy = "course")
    private List<Registration> registrations = new ArrayList<>();

    public Course() {
    }

    public Course(UUID id, String title, int credits, Department department, List<Lecturer> lecturers,
            List<Registration> registrations) {
        this.id = id;
        this.title = title;
        this.credits = credits;
        this.department = department;
        this.lecturers = lecturers;
        this.registrations = registrations;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public List<Lecturer> getLecturers() {
        return lecturers;
    }

    public void setLecturers(List<Lecturer> lecturers) {
        this.lecturers = lecturers;
    }

    public List<Registration> getRegistrations() {
        return registrations;
    }

    public void setRegistrations(List<Registration> registrations) {
        this.registrations = registrations;
    }

    
}
