package com.auca.university.model;

import java.time.LocalDate;
import java.util.*;

import jakarta.persistence.*;


@Entity
public class Registration {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
 
    private LocalDate registrationDate;
 

    private String academicYear; 
 
    private Integer semester;
 
    @Enumerated(EnumType.STRING)

    private RegistrationStatus status = RegistrationStatus.PENDING;
 

    private String grade;
 
    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;
 
    @ManyToOne
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    public Registration() {
    }

    public Registration(UUID id, LocalDate registrationDate, String academicYear, Integer semester,
            RegistrationStatus status, String grade, Student student, Course course) {
        this.id = id;
        this.registrationDate = registrationDate;
        this.academicYear = academicYear;
        this.semester = semester;
        this.status = status;
        this.grade = grade;
        this.student = student;
        this.course = course;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getAcademicYear() {
        return academicYear;
    }

    public void setAcademicYear(String academicYear) {
        this.academicYear = academicYear;
    }

    public Integer getSemester() {
        return semester;
    }

    public void setSemester(Integer semester) {
        this.semester = semester;
    }

    public RegistrationStatus getStatus() {
        return status;
    }

    public void setStatus(RegistrationStatus status) {
        this.status = status;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
    
}
