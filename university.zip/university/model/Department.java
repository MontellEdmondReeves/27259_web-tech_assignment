package com.auca.university.model;

import java.util.*;

import jakarta.persistence.*;

@Entity
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
 
    private String name;
 
 
    @OneToOne
    @JoinColumn(name = "head_lecturer_id", unique = true)
    private Lecturer head;
 
    @OneToMany(mappedBy = "department")
    private List<Lecturer> lecturers = new ArrayList<>();

    
    @OneToMany(mappedBy = "department")
    private List<Course> courses = new ArrayList<>();
 
    @OneToMany(mappedBy = "department")
    private List<Student> students = new ArrayList<>();

    public Department() {
    }

    public Department(UUID id, String name, Lecturer head, List<Lecturer> lecturers, List<Course> courses,
            List<Student> students) {
        this.id = id;
        this.name = name;
        this.head = head;
        this.lecturers = lecturers;
        this.courses = courses;
        this.students = students;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Lecturer getHead() {
        return head;
    }

    public void setHead(Lecturer head) {
        this.head = head;
    }

    public List<Lecturer> getLecturers() {
        return lecturers;
    }

    public void setLecturers(List<Lecturer> lecturers) {
        this.lecturers = lecturers;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    

}