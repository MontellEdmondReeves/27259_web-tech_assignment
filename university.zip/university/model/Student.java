package com.auca.university.model;

import java.time.LocalDate;
import java.util.*;
import jakarta.persistence.*;

@Entity
public class Student {
 
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
 

    private String studentNumber;

    private String name;
 
    private String email;
 
    private LocalDate admissionDate;
 
    @ManyToOne
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;
 
    /** One-to-One (inverse side). The FK student_id lives in student_profiles. */
    @OneToOne(mappedBy = "student")
    private StudentProfile profile;
 
    /** One student has many registrations (join entity). */
    @OneToMany(mappedBy = "student")
    private List<Registration> registrations = new ArrayList<>();

    public Student() {
    }

    public Student(UUID id, String studentNumber, String name, String email, LocalDate admissionDate,
            Department department, StudentProfile profile, List<Registration> registrations) {
        this.id = id;
        this.studentNumber = studentNumber;
        this.name = name;
        this.email = email;
        this.admissionDate = admissionDate;
        this.department = department;
        this.profile = profile;
        this.registrations = registrations;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getAdmissionDate() {
        return admissionDate;
    }

    public void setAdmissionDate(LocalDate admissionDate) {
        this.admissionDate = admissionDate;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public StudentProfile getProfile() {
        return profile;
    }

    public void setProfile(StudentProfile profile) {
        this.profile = profile;
    }

    public List<Registration> getRegistrations() {
        return registrations;
    }

    public void setRegistrations(List<Registration> registrations) {
        this.registrations = registrations;
    }

    

}
