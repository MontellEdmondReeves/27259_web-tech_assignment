package com.auca.university.model;

/**
 * Gender
 */
public enum Gender {

    MALE, FEMALE
}