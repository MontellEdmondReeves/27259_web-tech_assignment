package com.auca.university.model;

/**
 * RegistrationStatus
 */
public enum RegistrationStatus {

    PENDING, APPROVED, REJECTED
}