package com.auca.university.model;

import java.util.*;

import jakarta.persistence.*;

@Entity 
public class Lecturer {

     
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

 
    private String name;
 
    private String email;
 
    /** Many lecturers belong to one department (FK department_id). */
    @ManyToOne
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;
 
    /** Inverse side of the one-to-one head relationship. */
    @OneToOne(mappedBy = "head")
    private Department headOfDepartment;
 
    /** Many-to-Many with Course. This side OWNS the join table. */
    @ManyToMany
    @JoinTable(
        name = "lecturer_course",
        joinColumns = @JoinColumn(name = "lecturer_id"),
        inverseJoinColumns = @JoinColumn(name = "course_id")
    )
    private List<Course> courses = new ArrayList<>();

    public Lecturer() {
    }

    public Lecturer(UUID id, String name, String email, Department department, Department headOfDepartment,
            List<Course> courses) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.department = department;
        this.headOfDepartment = headOfDepartment;
        this.courses = courses;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Department getHeadOfDepartment() {
        return headOfDepartment;
    }

    public void setHeadOfDepartment(Department headOfDepartment) {
        this.headOfDepartment = headOfDepartment;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

}