package com.auca.university.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auca.university.model.StudentProfile;

public interface StudentProfileRepository extends JpaRepository<StudentProfile, UUID>{
    @Override
    default Optional<StudentProfile> findById(UUID id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }
}
