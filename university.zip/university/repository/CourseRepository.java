package com.auca.university.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auca.university.model.Course;

/**
 * CourseRepository
 */
public interface CourseRepository extends JpaRepository<Course, UUID> {
    @Override
    default Optional<Course> findById(UUID id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }
    
}