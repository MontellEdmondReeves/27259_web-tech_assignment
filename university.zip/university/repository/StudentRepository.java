package com.auca.university.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auca.university.model.Student;

public interface StudentRepository extends JpaRepository <Student, UUID>{
    @Override
    default Optional<Student> findById(UUID id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }
}
