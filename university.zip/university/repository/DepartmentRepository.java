package com.auca.university.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auca.university.model.Department;

public interface DepartmentRepository extends JpaRepository <Department, UUID>{
    @Override
    default Optional<Department> findById(UUID id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }
}
