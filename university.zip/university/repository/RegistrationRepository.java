package com.auca.university.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auca.university.model.Registration;

public interface RegistrationRepository extends JpaRepository<Registration, UUID>{
    @Override
    default Optional<Registration> findById(UUID id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }
}
